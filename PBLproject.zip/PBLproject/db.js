// Database configuration
const DB_NAME = 'FoodFlowDB';
const DB_VERSION = 1;
const STORE_NAME = 'items';

// Database operations class
class FoodFlowDB {
    constructor() {
        this.db = null;
        this.initDB();
    }

    // Initialize the database
    async initDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = () => {
                console.error('Error opening database:', request.error);
                reject(request.error);
            };

            request.onsuccess = () => {
                this.db = request.result;
                console.log('Database opened successfully');
                resolve();
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    const store = db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
                    store.createIndex('name', 'name', { unique: false });
                    store.createIndex('expiryDate', 'expiryDate', { unique: false });
                }
            };
        });
    }

    // Add a new item
    async addItem(item) {
        if (!this.db) throw new Error('Database not initialized');
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([STORE_NAME], 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.add({
                name: item.name,
                expiryDate: item.expiryDate,
                createdAt: new Date().toISOString()
            });

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Get all items
    async getAllItems() {
        if (!this.db) throw new Error('Database not initialized');
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([STORE_NAME], 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Delete an item
    async deleteItem(id) {
        if (!this.db) throw new Error('Database not initialized');
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([STORE_NAME], 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.delete(id);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Search items by name
    async searchItems(searchTerm) {
        if (!this.db) throw new Error('Database not initialized');
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([STORE_NAME], 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.getAll();

            request.onsuccess = () => {
                const items = request.result.filter(item => 
                    item.name.toLowerCase().includes(searchTerm.toLowerCase())
                );
                resolve(items);
            };
            request.onerror = () => reject(request.error);
        });
    }
}

// Create a global instance of the database
const db = new FoodFlowDB();

// Export functions for use in other files
window.dbOperations = {
    addItem: async (item) => {
        try {
            await db.addItem(item);
            return true;
        } catch (error) {
            console.error('Error adding item:', error);
            return false;
        }
    },

    getAllItems: async () => {
        try {
            return await db.getAllItems();
        } catch (error) {
            console.error('Error getting items:', error);
            return [];
        }
    },

    deleteItem: async (id) => {
        try {
            await db.deleteItem(id);
            return true;
        } catch (error) {
            console.error('Error deleting item:', error);
            return false;
        }
    },

    searchItems: async (searchTerm) => {
        try {
            return await db.searchItems(searchTerm);
        } catch (error) {
            console.error('Error searching items:', error);
            return [];
        }
    }
}; 