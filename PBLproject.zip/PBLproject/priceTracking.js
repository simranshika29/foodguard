// Price tracking and sales strategy functionality

// Price history storage
const PRICE_HISTORY_KEY = 'foodflow_price_history';
const SALES_HISTORY_KEY = 'foodflow_sales_history';

// Initialize price tracking
function initPriceTracking() {
    if (!localStorage.getItem(PRICE_HISTORY_KEY)) {
        localStorage.setItem(PRICE_HISTORY_KEY, JSON.stringify({}));
    }
    if (!localStorage.getItem(SALES_HISTORY_KEY)) {
        localStorage.setItem(SALES_HISTORY_KEY, JSON.stringify({}));
    }
}

// Get price history for an item
function getPriceHistory(itemId) {
    const history = JSON.parse(localStorage.getItem(PRICE_HISTORY_KEY) || '{}');
    return history[itemId] || [];
}

// Get sales history for an item
function getSalesHistory(itemId) {
    const history = JSON.parse(localStorage.getItem(SALES_HISTORY_KEY) || '{}');
    return history[itemId] || [];
}

// Add price record
function addPriceRecord(itemId, price, date = new Date().toISOString()) {
    const history = JSON.parse(localStorage.getItem(PRICE_HISTORY_KEY) || '{}');
    if (!history[itemId]) {
        history[itemId] = [];
    }
    history[itemId].push({ price, date });
    localStorage.setItem(PRICE_HISTORY_KEY, JSON.stringify(history));
}

// Add sales record
function addSalesRecord(itemId, quantity, price, strategy, date = new Date().toISOString()) {
    const history = JSON.parse(localStorage.getItem(SALES_HISTORY_KEY) || '{}');
    if (!history[itemId]) {
        history[itemId] = [];
    }
    history[itemId].push({ quantity, price, strategy, date });
    localStorage.setItem(SALES_HISTORY_KEY, JSON.stringify(history));
}

// Calculate best selling strategy
function calculateBestStrategy(itemId) {
    const salesHistory = getSalesHistory(itemId);
    const priceHistory = getPriceHistory(itemId);
    
    if (salesHistory.length === 0) {
        return {
            strategy: 'discount',
            confidence: 0.5,
            reason: 'No sales history available'
        };
    }

    // Calculate success rates for each strategy
    const strategies = {
        discount: { count: 0, total: 0 },
        bulk: { count: 0, total: 0 },
        bundle: { count: 0, total: 0 }
    };

    salesHistory.forEach(sale => {
        strategies[sale.strategy].total++;
        if (sale.quantity > 0) {
            strategies[sale.strategy].count++;
        }
    });

    // Calculate success rates
    const successRates = {
        discount: strategies.discount.total > 0 ? strategies.discount.count / strategies.discount.total : 0,
        bulk: strategies.bulk.total > 0 ? strategies.bulk.count / strategies.bulk.total : 0,
        bundle: strategies.bundle.total > 0 ? strategies.bundle.count / strategies.bundle.total : 0
    };

    // Find best strategy
    let bestStrategy = 'discount';
    let bestRate = successRates.discount;

    if (successRates.bulk > bestRate) {
        bestStrategy = 'bulk';
        bestRate = successRates.bulk;
    }
    if (successRates.bundle > bestRate) {
        bestStrategy = 'bundle';
        bestRate = successRates.bundle;
    }

    return {
        strategy: bestStrategy,
        confidence: bestRate,
        reason: `Based on ${salesHistory.length} previous sales`
    };
}

// Get product insights
function getProductInsights(itemId) {
    const salesHistory = getSalesHistory(itemId);
    const priceHistory = getPriceHistory(itemId);
    
    // Calculate monthly sales
    const currentMonth = new Date().getMonth();
    const monthlySales = salesHistory.filter(sale => {
        const saleDate = new Date(sale.date);
        return saleDate.getMonth() === currentMonth;
    });

    // Calculate average price
    const avgPrice = priceHistory.length > 0
        ? priceHistory.reduce((sum, record) => sum + record.price, 0) / priceHistory.length
        : 0;

    // Calculate total sales
    const totalSales = monthlySales.reduce((sum, sale) => sum + sale.quantity, 0);

    return {
        monthlySales: totalSales,
        averagePrice: avgPrice,
        totalTransactions: monthlySales.length,
        bestStrategy: calculateBestStrategy(itemId)
    };
}

// Get storage requirements
function getStorageRequirements(itemId) {
    // This would typically come from a product database
    // For now, we'll return some example data
    return {
        temperature: '2-4°C',
        humidity: '85-95%',
        light: 'Keep away from direct sunlight',
        notes: 'Store in original packaging'
    };
}

// Show product details modal
function showProductDetails(itemId, item) {
    const insights = getProductInsights(itemId);
    const storage = getStorageRequirements(itemId);
    
    const modal = document.createElement('div');
    modal.className = 'modal product-details-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${item.name}</h2>
                <button class="close-modal" onclick="this.closest('.modal').remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="product-info">
                    <div class="info-section">
                        <h3>Current Stock</h3>
                        <p>${item.quantity} units</p>
                    </div>
                    <div class="info-section">
                        <h3>Expiration</h3>
                        <p>${new Date(item.expiryDate).toLocaleDateString()}</p>
                    </div>
                    <div class="info-section">
                        <h3>Best Selling Strategy</h3>
                        <p>${insights.bestStrategy.strategy} (${Math.round(insights.bestStrategy.confidence * 100)}% confidence)</p>
                    </div>
                    <div class="info-section">
                        <h3>Monthly Sales</h3>
                        <p>${insights.monthlySales} units</p>
                    </div>
                    <div class="info-section">
                        <h3>Average Price</h3>
                        <p>$${insights.averagePrice.toFixed(2)}</p>
                    </div>
                    <div class="info-section">
                        <h3>Storage Requirements</h3>
                        <ul>
                            <li>Temperature: ${storage.temperature}</li>
                            <li>Humidity: ${storage.humidity}</li>
                            <li>Light: ${storage.light}</li>
                            <li>${storage.notes}</li>
                        </ul>
                    </div>
                </div>
                <div class="action-buttons">
                    <button onclick="applyStrategy('${itemId}', 'discount')" class="action-btn">
                        <i class="fas fa-percentage"></i> Apply Discount
                    </button>
                    <button onclick="applyStrategy('${itemId}', 'bulk')" class="action-btn">
                        <i class="fas fa-box"></i> Bulk Sale
                    </button>
                    <button onclick="applyStrategy('${itemId}', 'bundle')" class="action-btn">
                        <i class="fas fa-gift"></i> Bundle Deal
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.classList.add('active');
}

// Apply sales strategy
function applyStrategy(itemId, strategy) {
    const item = window.api.getItem(itemId);
    if (!item) {
        window.utils.showNotification('Item not found', 'error');
        return;
    }

    const insights = getProductInsights(itemId);
    const bestStrategy = insights.bestStrategy;

    // If the chosen strategy matches the best strategy, apply a better discount
    const discount = strategy === bestStrategy.strategy ? 0.2 : 0.1;
    
    // Calculate new price
    const newPrice = item.price * (1 - discount);
    
    // Record the price change and sale
    addPriceRecord(itemId, newPrice);
    addSalesRecord(itemId, item.quantity, newPrice, strategy);
    
    // Update item price
    window.api.updateItem(itemId, { ...item, price: newPrice });
    
    // Show success message
    window.utils.showNotification(
        `${strategy.charAt(0).toUpperCase() + strategy.slice(1)} applied with ${Math.round(discount * 100)}% discount`,
        'success'
    );
    
    // Close the modal
    const modal = document.querySelector('.product-details-modal');
    if (modal) modal.remove();
}

// Initialize price tracking when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initPriceTracking();
});

// Export functions
window.priceTracking = {
    initPriceTracking,
    getPriceHistory,
    getSalesHistory,
    addPriceRecord,
    addSalesRecord,
    calculateBestStrategy,
    getProductInsights,
    getStorageRequirements,
    showProductDetails,
    applyStrategy
}; 