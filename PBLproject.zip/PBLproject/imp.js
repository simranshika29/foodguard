// Database configuration
const DB_NAME = 'FoodFlowDB';
const DB_VERSION = 1;
const STORE_NAME = 'items';

// Database operations class
class FoodFlowDB {
    constructor() {
        this.db = null;
        this.initDB();
    }

    // Initialize the database
    async initDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = () => {
                console.error('Error opening database:', request.error);
                reject(request.error);
            };

            request.onsuccess = () => {
                this.db = request.result;
                console.log('Database opened successfully');
                resolve();
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    const store = db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
                    store.createIndex('name', 'name', { unique: false });
                    store.createIndex('expiryDate', 'expiryDate', { unique: false });
                    console.log('Database schema updated');
                }
            };
        });
    }

    // Add a new item
    async addItem(item) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject(new Error('Database not initialized'));
                return;
            }

            const transaction = this.db.transaction([STORE_NAME], 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.add({
                name: item.name,
                expiryDate: item.expiryDate,
                createdAt: new Date().toISOString()
            });

            request.onsuccess = () => {
                console.log('Item added successfully:', request.result);
                resolve(request.result);
            };

            request.onerror = () => {
                console.error('Error adding item:', request.error);
                reject(request.error);
            };
        });
    }

    // Get all items
    async getAllItems() {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject(new Error('Database not initialized'));
                return;
            }

            const transaction = this.db.transaction([STORE_NAME], 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.getAll();

            request.onsuccess = () => {
                console.log('Items retrieved successfully:', request.result);
                resolve(request.result);
            };

            request.onerror = () => {
                console.error('Error retrieving items:', request.error);
                reject(request.error);
            };
        });
    }

    // Delete an item
    async deleteItem(id) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject(new Error('Database not initialized'));
                return;
            }

            const transaction = this.db.transaction([STORE_NAME], 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.delete(id);

            request.onsuccess = () => {
                console.log('Item deleted successfully');
                resolve();
            };

            request.onerror = () => {
                console.error('Error deleting item:', request.error);
                reject(request.error);
            };
        });
    }

    // Update an item
    async updateItem(id, item) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject(new Error('Database not initialized'));
                return;
            }

            const transaction = this.db.transaction([STORE_NAME], 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.put({
                id: id,
                name: item.name,
                expiryDate: item.expiryDate,
                createdAt: item.createdAt
            });

            request.onsuccess = () => {
                console.log('Item updated successfully:', request.result);
                resolve(request.result);
            };

            request.onerror = () => {
                console.error('Error updating item:', request.error);
                reject(request.error);
            };
        });
    }

    // Search items by name
    async searchItems(searchTerm) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject(new Error('Database not initialized'));
                return;
            }

            const transaction = this.db.transaction([STORE_NAME], 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.getAll();

            request.onsuccess = () => {
                const items = request.result.filter(item => 
                    item.name.toLowerCase().includes(searchTerm.toLowerCase())
                );
                items.sort((a, b) => a.name.localeCompare(b.name));
                console.log('Search results:', items);
                resolve(items);
            };

            request.onerror = () => {
                console.error('Error searching items:', request.error);
                reject(request.error);
            };
        });
    }

    // Get expiring items (within 3 days)
    async getExpiringItems() {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject(new Error('Database not initialized'));
                return;
            }

            const transaction = this.db.transaction([STORE_NAME], 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.getAll();

            request.onsuccess = () => {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const threeDaysFromNow = new Date(today);
                threeDaysFromNow.setDate(today.getDate() + 3);

                const expiringItems = request.result.filter(item => {
                    const expiryDate = new Date(item.expiryDate);
                    return expiryDate >= today && expiryDate <= threeDaysFromNow;
                });

                console.log('Expiring items:', expiringItems);
                resolve(expiringItems);
            };

            request.onerror = () => {
                console.error('Error getting expiring items:', request.error);
                reject(request.error);
            };
        });
    }
}

// Create a global instance of the database
const db = new FoodFlowDB();

// Export functions for use in front.html
window.dbOperations = {
    addItem: async (item) => {
        try {
            await db.addItem(item);
            return true;
        } catch (error) {
            console.error('Error adding item:', error);
            return false;
        }
    },

    getAllItems: async () => {
        try {
            return await db.getAllItems();
        } catch (error) {
            console.error('Error getting items:', error);
            return [];
        }
    },

    deleteItem: async (id) => {
        try {
            await db.deleteItem(id);
            return true;
        } catch (error) {
            console.error('Error deleting item:', error);
            return false;
        }
    },

    updateItem: async (id, item) => {
        try {
            await db.updateItem(id, item);
            return true;
        } catch (error) {
            console.error('Error updating item:', error);
            return false;
        }
    },

    searchItems: async (searchTerm) => {
        try {
            return await db.searchItems(searchTerm);
        } catch (error) {
            console.error('Error searching items:', error);
            return [];
        }
    },

    getExpiringItems: async () => {
        try {
            return await db.getExpiringItems();
        } catch (error) {
            console.error('Error getting expiring items:', error);
            return [];
        }
    }
};

// Add event listener for search input
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            window.filterItems();
        });
    }
});
