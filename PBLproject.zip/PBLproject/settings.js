// Settings functionality
const SETTINGS_KEY = 'foodFlowSettings';
const DATA_KEY = 'foodFlowData';

// Default settings
const defaultSettings = {
    emailNotifications: true,
    browserNotifications: true,
    apiKey: '',
    theme: 'light',
    isSignedIn: false,
    username: ''
};

// Get current settings
function getSettings() {
    const savedSettings = localStorage.getItem(SETTINGS_KEY);
    return savedSettings ? { ...defaultSettings, ...JSON.parse(savedSettings) } : defaultSettings;
}

// Save settings
function saveSettings(settings) {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    applySettings(settings);
}

// Apply settings to the UI
function applySettings(settings) {
    // Update checkboxes
    document.getElementById('emailNotifications').checked = settings.emailNotifications;
    document.getElementById('browserNotifications').checked = settings.browserNotifications;
    
    // Update API key input
    const apiKeyInput = document.getElementById('apiKeyInput');
    if (apiKeyInput) {
        apiKeyInput.value = settings.apiKey;
    }
    
    // Update account status
    const accountStatus = document.querySelector('.account-status');
    if (accountStatus) {
        accountStatus.textContent = settings.isSignedIn ? `Signed in as ${settings.username}` : 'Not signed in';
    }
    
    // Apply theme
    document.body.setAttribute('data-theme', settings.theme);
}

// Save API key
function saveApiKey() {
    const apiKeyInput = document.getElementById('apiKeyInput');
    if (!apiKeyInput) return;
    
    const settings = getSettings();
    settings.apiKey = apiKeyInput.value.trim();
    saveSettings(settings);
    window.utils.showNotification('API key saved successfully!');
}

// Toggle notification settings
function toggleNotification(type) {
    const settings = getSettings();
    settings[type] = !settings[type];
    saveSettings(settings);
    window.utils.showNotification(`${type.replace('Notifications', '')} notifications ${settings[type] ? 'enabled' : 'disabled'}`);
}

// Show sign in prompt
function showSignInPrompt() {
    const username = prompt('Enter your username:');
    if (username) {
        const settings = getSettings();
        settings.isSignedIn = true;
        settings.username = username;
        saveSettings(settings);
        window.utils.showNotification(`Signed in as ${username}`);
    }
}

// Export data
async function exportData() {
    try {
        const data = {
            items: await window.dbOperations.getAllItems(),
            settings: getSettings()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'foodflow_backup.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        window.utils.showNotification('Data exported successfully!');
    } catch (error) {
        console.error('Error exporting data:', error);
        window.utils.showNotification('Error exporting data', 'warning');
    }
}

// Import data
async function importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        try {
            const text = await file.text();
            const data = JSON.parse(text);
            
            // Import items
            if (data.items) {
                for (const item of data.items) {
                    await window.dbOperations.addItem(item);
                }
            }
            
            // Import settings
            if (data.settings) {
                saveSettings(data.settings);
            }
            
            window.utils.showNotification('Data imported successfully!');
            window.location.reload(); // Refresh to show imported data
        } catch (error) {
            console.error('Error importing data:', error);
            window.utils.showNotification('Error importing data', 'warning');
        }
    };
    
    input.click();
}

// Initialize settings
function initializeSettings() {
    const settings = getSettings();
    applySettings(settings);
    
    // Add event listeners
    const emailCheckbox = document.getElementById('emailNotifications');
    const browserCheckbox = document.getElementById('browserNotifications');
    
    if (emailCheckbox) {
        emailCheckbox.addEventListener('change', () => toggleNotification('emailNotifications'));
    }
    
    if (browserCheckbox) {
        browserCheckbox.addEventListener('change', () => toggleNotification('browserNotifications'));
    }
}

// Export settings functions
window.settings = {
    initializeSettings,
    saveApiKey,
    getSettings,
    showSignInPrompt,
    exportData,
    importData
}; 