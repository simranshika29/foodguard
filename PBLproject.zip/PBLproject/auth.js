// Authentication and data management functionality

// User authentication state
let currentUser = null;

// Initialize authentication
function initAuth() {
    console.log('Initializing authentication...');
    // Check for existing session
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            // Verify user still exists
            if (userExists(currentUser.email)) {
                console.log('Found valid saved user:', currentUser.email);
                updateAuthUI();
                showMainContent();
                loadUserData();
            } else {
                // User no longer exists, clear session
                console.log('Saved user no longer exists, clearing session');
                signOut();
            }
        } catch (error) {
            console.error('Error parsing saved user:', error);
            signOut();
        }
    } else {
        console.log('No saved user found');
        hideMainContent();
    }

    // Set up form event listeners
    setupAuthForms();
    console.log('Authentication initialized');
}

// Set up authentication form event listeners
function setupAuthForms() {
    console.log('Setting up auth forms...');
    // Sign In Form
    const signInForm = document.getElementById('signInForm');
    if (!signInForm) {
        console.error('Sign in form not found!');
        return;
    }
    
    signInForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        console.log('Sign in form submitted');
        const email = document.getElementById('signInEmail').value;
        const password = document.getElementById('signInPassword').value;
        
        try {
            const success = await signIn(email, password);
            if (success) {
                closeAuthModal();
                showMainContent();
            }
        } catch (error) {
            window.utils.showNotification(error.message, 'error');
        }
    });

    // Sign Up Form
    const signUpForm = document.getElementById('signUpForm');
    if (!signUpForm) {
        console.error('Sign up form not found!');
        return;
    }
    
    signUpForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        console.log('Sign up form submitted');
        const email = document.getElementById('signUpEmail').value;
        const password = document.getElementById('signUpPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            window.utils.showNotification('Passwords do not match', 'error');
            return;
        }

        try {
            const success = await signUp(email, password);
            if (success) {
                closeAuthModal();
                showMainContent();
            }
        } catch (error) {
            window.utils.showNotification(error.message, 'error');
        }
    });
    console.log('Auth forms setup complete');
}

// Show authentication modal
function showAuthModal() {
    console.log('Showing auth modal...');
    const modal = document.getElementById('authModal');
    if (!modal) {
        console.error('Auth modal not found!');
        return;
    }
    modal.classList.add('active');
    hideMainContent();
    console.log('Auth modal shown');
}

// Close authentication modal
function closeAuthModal() {
    const modal = document.getElementById('authModal');
    if (modal) {
        modal.classList.remove('active');
        // Reset forms
        const signInForm = document.getElementById('signInForm');
        const signUpForm = document.getElementById('signUpForm');
        if (signInForm) signInForm.reset();
        if (signUpForm) signUpForm.reset();
    }
}

// Show sign in form
function showSignInForm() {
    const signInForm = document.getElementById('signInForm');
    const signUpForm = document.getElementById('signUpForm');
    const title = document.getElementById('authModalTitle');
    
    if (signInForm && signUpForm && title) {
        signInForm.style.display = 'flex';
        signUpForm.style.display = 'none';
        title.textContent = 'Sign In';
    }
}

// Show sign up form
function showSignUpForm() {
    const signInForm = document.getElementById('signInForm');
    const signUpForm = document.getElementById('signUpForm');
    const title = document.getElementById('authModalTitle');
    
    if (signInForm && signUpForm && title) {
        signInForm.style.display = 'none';
        signUpForm.style.display = 'flex';
        title.textContent = 'Create Account';
    }
}

// User accounts storage
const USERS_KEY = 'foodflow_users';
const USER_DATA_PREFIX = 'foodflow_data_';

// Get all registered users
function getUsers() {
    const users = localStorage.getItem(USERS_KEY);
    return users ? JSON.parse(users) : {};
}

// Save users
function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// Get user data key
function getUserDataKey(email) {
    return USER_DATA_PREFIX + email.toLowerCase();
}

// Check if user exists
function userExists(email) {
    const users = getUsers();
    return !!users[email.toLowerCase()];
}

// Create new account
function createAccount(email, password) {
    const users = getUsers();
    const userEmail = email.toLowerCase();
    
    if (users[userEmail]) {
        throw new Error('Account already exists');
    }

    // Hash password (in a real app, use a proper hashing algorithm)
    const hashedPassword = btoa(password); // This is just for demonstration

    users[userEmail] = {
        email: userEmail,
        password: hashedPassword,
        createdAt: new Date().toISOString()
    };
    saveUsers(users);
    return true;
}

// Sign in function
async function signIn(email, password) {
    try {
        if (!email || !password) {
            throw new Error('Please enter both email and password');
        }

        const userEmail = email.toLowerCase();
        
        // Check if user exists
        if (!userExists(userEmail)) {
            throw new Error('Account does not exist. Please sign up first.');
        }

        const users = getUsers();
        // Verify password (in a real app, use proper password comparison)
        const hashedPassword = btoa(password);
        if (users[userEmail].password !== hashedPassword) {
            throw new Error('Invalid password');
        }

        // Set current user
        currentUser = {
            email: userEmail,
            name: email.split('@')[0],
            token: 'token-' + Date.now()
        };

        // Save session
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Update UI
        updateAuthUI();
        
        // Load user data
        loadUserData();
        
        window.utils.showNotification('Successfully signed in', 'success');
        return true;
    } catch (error) {
        window.utils.showNotification(error.message, 'error');
        return false;
    }
}

// Sign up function
async function signUp(email, password) {
    try {
        if (!email || !password) {
            throw new Error('Please enter both email and password');
        }

        const userEmail = email.toLowerCase();
        
        // Check if user already exists
        if (userExists(userEmail)) {
            throw new Error('Account already exists. Please sign in instead.');
        }

        // Create new account
        createAccount(userEmail, password);
        
        // Automatically sign in after successful sign up
        await signIn(email, password);
        
        window.utils.showNotification('Account created successfully!', 'success');
        return true;
    } catch (error) {
        window.utils.showNotification(error.message, 'error');
        return false;
    }
}

// Sign out function
async function signOut() {
    try {
        // Clear current user from localStorage
        localStorage.removeItem('currentUser');
        
        // Clear user data
        clearUserData();
        
        // Reset current user state
        currentUser = null;
        
        // Hide main content and show auth modal
        hideMainContent();
        
        // Update UI
        updateAuthUI();
        
        window.utils.showNotification('Successfully signed out', 'success');
    } catch (error) {
        console.error('Sign out error:', error);
        window.utils.showNotification('Failed to sign out', 'error');
    }
}

// Update UI based on auth state
function updateAuthUI() {
    const signInBtn = document.querySelector('.sign-in-btn');
    const accountStatus = document.querySelector('.account-status');
    const addItemBtn = document.getElementById('addItemBtn');
    const exportBtn = document.getElementById('exportBtn');
    const importBtn = document.getElementById('importBtn');
    
    if (currentUser) {
        if (signInBtn) {
            signInBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Sign Out';
            signInBtn.onclick = signOut;
        }
        if (accountStatus) {
            accountStatus.textContent = `Signed in as ${currentUser.email}`;
        }
        // Enable features for logged-in users
        if (addItemBtn) addItemBtn.disabled = false;
        if (exportBtn) exportBtn.disabled = false;
        if (importBtn) importBtn.disabled = false;
    } else {
        if (signInBtn) {
            signInBtn.innerHTML = '<i class="fas fa-user"></i> Sign In';
            signInBtn.onclick = showAuthModal;
        }
        if (accountStatus) {
            accountStatus.textContent = 'Not signed in';
        }
        // Disable features for non-logged-in users
        if (addItemBtn) addItemBtn.disabled = true;
        if (exportBtn) exportBtn.disabled = true;
        if (importBtn) importBtn.disabled = true;
    }
}

// Load user-specific data
function loadUserData() {
    if (!currentUser) return;

    const userDataKey = getUserDataKey(currentUser.email);
    const userData = localStorage.getItem(userDataKey);
    
    if (userData) {
        const data = JSON.parse(userData);
        // Restore items
        if (data.items) {
            window.api.clearAllItems();
            data.items.forEach(item => window.api.addItem(item));
        }
        // Restore settings
        if (data.settings?.notifications) {
            document.getElementById('emailNotifications').checked = data.settings.notifications.email;
            document.getElementById('browserNotifications').checked = data.settings.notifications.browser;
        }
    }
}

// Save user-specific data
function saveUserData() {
    if (!currentUser) return;

    const userDataKey = getUserDataKey(currentUser.email);
    const data = {
        items: window.api.getAllItems(),
        settings: {
            notifications: {
                email: document.getElementById('emailNotifications').checked,
                browser: document.getElementById('browserNotifications').checked
            }
        }
    };

    localStorage.setItem(userDataKey, JSON.stringify(data));
}

// Clear user data from memory and storage
function clearUserData() {
    // Clear items from storage
    window.api.clearAllItems();
    
    // Reset settings
    document.getElementById('emailNotifications').checked = false;
    document.getElementById('browserNotifications').checked = false;
    
    // Clear any other user-specific data
    if (currentUser) {
        localStorage.removeItem(getUserDataKey(currentUser.email));
    }
}

// Export data function
function exportData() {
    if (!currentUser) {
        window.utils.showNotification('Please sign in to export data', 'error');
        return;
    }

    try {
        const userDataKey = getUserDataKey(currentUser.email);
        const userData = localStorage.getItem(userDataKey);
        
        if (!userData) {
            throw new Error('No data to export');
        }

        const blob = new Blob([userData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `foodflow-export-${currentUser.email}-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        window.utils.showNotification('Data exported successfully', 'success');
    } catch (error) {
        window.utils.showNotification('Failed to export data: ' + error.message, 'error');
    }
}

// Import data function
async function importData() {
    if (!currentUser) {
        window.utils.showNotification('Please sign in to import data', 'error');
        return;
    }

    try {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,.csv';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = async (event) => {
                try {
                    let data;
                    if (file.name.endsWith('.csv')) {
                        // Parse CSV data
                        const csvText = event.target.result;
                        const rows = csvText.split('\n').filter(row => row.trim()); // Remove empty rows
                        
                        if (rows.length < 2) {
                            throw new Error('CSV file is empty or has no data rows');
                        }

                        const headers = rows[0].split(',').map(h => h.trim());
                        const requiredHeaders = ['Item Name', 'Quantity', 'Expiry Date'];
                        
                        // Validate headers
                        const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
                        if (missingHeaders.length > 0) {
                            throw new Error(`Missing required columns: ${missingHeaders.join(', ')}`);
                        }

                        // Get column indices
                        const nameIndex = headers.indexOf('Item Name');
                        const quantityIndex = headers.indexOf('Quantity');
                        const expiryIndex = headers.indexOf('Expiry Date');

                        data = {
                            items: rows.slice(1)
                                .map(row => {
                                    const values = row.split(',').map(v => v.trim());
                                    const item = {
                                        name: values[nameIndex].replace(/[^\w\s-]/g, '').trim(), // Remove special characters
                                        quantity: parseInt(values[quantityIndex]) || 1,
                                        expiryDate: values[expiryIndex],
                                        createdAt: new Date().toISOString()
                                    };
                                    return item;
                                })
                                .filter(item => {
                                    // Validate expiry date
                                    const expiryDate = new Date(item.expiryDate);
                                    const minDate = new Date('2025-04-01');
                                    const maxDate = new Date('2025-12-31');
                                    return expiryDate >= minDate && expiryDate <= maxDate;
                                })
                        };
                    } else {
                        // Parse JSON data
                        data = JSON.parse(event.target.result);
                    }

                    // Validate data structure
                    if (!data.items || !Array.isArray(data.items)) {
                        throw new Error('Invalid data format');
                    }

                    // Clear existing data
                    window.api.clearAllItems();

                    // Import items
                    let successCount = 0;
                    let errorCount = 0;
                    let skippedCount = 0;
                    
                    for (const item of data.items) {
                        try {
                            // Format and validate the item
                            const formattedItem = {
                                name: item.name,
                                quantity: item.quantity || 0,
                                expiryDate: item.expiryDate,
                                category: item.category || 'Uncategorized',
                                createdAt: new Date().toISOString()
                            };

                            // Validate required fields
                            if (!formattedItem.name || !formattedItem.expiryDate) {
                                console.error('Invalid item format:', item);
                                errorCount++;
                                continue;
                            }

                            // Validate date format and range
                            const expiryDate = new Date(formattedItem.expiryDate);
                            const minDate = new Date('2025-04-01');
                            const maxDate = new Date('2025-12-31');
                            
                            if (isNaN(expiryDate.getTime())) {
                                console.error('Invalid date format:', formattedItem.expiryDate);
                                errorCount++;
                                continue;
                            }

                            if (expiryDate < minDate || expiryDate > maxDate) {
                                console.error('Date out of range:', formattedItem.expiryDate);
                                skippedCount++;
                                continue;
                            }

                            // Format date to YYYY-MM-DD
                            formattedItem.expiryDate = expiryDate.toISOString().split('T')[0];

                            console.log('Adding item:', formattedItem);
                            
                            // Add item using the API
                            await window.api.addItem(formattedItem);
                            successCount++;
                            console.log('Item added successfully:', formattedItem);
                        } catch (error) {
                            console.error('Error adding item:', error);
                            errorCount++;
                        }
                    }

                    // Import settings if available
                    if (data.settings?.notifications) {
                        document.getElementById('emailNotifications').checked = data.settings.notifications.email;
                        document.getElementById('browserNotifications').checked = data.settings.notifications.browser;
                    }

                    // Save imported data
                    saveUserData();
                    
                    // Show appropriate notification
                    let message = `Successfully imported ${successCount} items`;
                    if (errorCount > 0) message += ` (${errorCount} failed)`;
                    if (skippedCount > 0) message += ` (${skippedCount} skipped due to invalid dates)`;
                    
                    window.utils.showNotification(
                        message,
                        errorCount > 0 ? 'warning' : 'success'
                    );

                    // Refresh the table
                    if (typeof loadItems === 'function') {
                        loadItems();
                    } else if (typeof window.loadItems === 'function') {
                        window.loadItems();
                    }
                } catch (error) {
                    console.error('Import error:', error);
                    window.utils.showNotification('Failed to import data: ' + error.message, 'error');
                }
            };
            reader.readAsText(file);
        };
        input.click();
    } catch (error) {
        console.error('Import setup error:', error);
        window.utils.showNotification('Failed to import data', 'error');
    }
}

// Auto-save user data when changes occur
setInterval(() => {
    if (currentUser) {
        saveUserData();
    }
}, 30000); // Save every 30 seconds

// Show main content after successful authentication
function showMainContent() {
    const mainContent = document.getElementById('mainContent');
    const authModal = document.getElementById('authModal');
    const accountStatus = document.querySelector('.account-status');
    
    if (mainContent) mainContent.style.display = 'block';
    if (authModal) authModal.classList.remove('active');
    if (accountStatus && currentUser) {
        accountStatus.textContent = `Signed in as ${currentUser.email}`;
    }
}

// Hide main content when logging out
function hideMainContent() {
    const mainContent = document.getElementById('mainContent');
    const authModal = document.getElementById('authModal');
    const accountStatus = document.querySelector('.account-status');
    
    if (mainContent) mainContent.style.display = 'none';
    if (authModal) authModal.classList.add('active');
    if (accountStatus) accountStatus.textContent = 'Not signed in';
}

// Initialize auth when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initAuth();
});

// Export functions
window.auth = {
    initAuth,
    signIn,
    signUp,
    signOut,
    showAuthModal,
    closeAuthModal,
    showSignInForm,
    showSignUpForm,
    exportData,
    importData
}; 