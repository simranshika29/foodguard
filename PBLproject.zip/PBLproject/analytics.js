// Analytics functionality

let charts = {
    expiryChart: null,
    statusChart: null,
    timelineChart: null
};

// Update analytics section
async function updateAnalytics() {
    try {
        const items = await window.api.getAllItems();
        console.log('Analytics items:', items);
        destroyCharts();
        updateCharts(items);
        updateAnalyticsTable(items);
    } catch (error) {
        console.error('Error updating analytics:', error);
        window.utils.showNotification('Error loading analytics data', 'warning');
    }
}

// Destroy existing charts
function destroyCharts() {
    Object.values(charts).forEach(chart => {
        if (chart) chart.destroy();
    });
    charts = {
        expiryChart: null,
        statusChart: null,
        timelineChart: null
    };
}

// Update all charts
function updateCharts(items) {
    const statuses = ['Fresh', 'Expiring Soon', 'Expired'];
    const colors = ['#4CAF50', '#FFC107', '#DC3545'];
    
    // Calculate status counts
    const statusCounts = statuses.map(status => 
        items.filter(i => window.utils.getStatus(window.utils.calculateDaysLeft(new Date(i.expiryDate))) === status).length
    );

    // Expiry Distribution Chart
    const expiryCtx = document.getElementById('expiryChart').getContext('2d');
    charts.expiryChart = new Chart(expiryCtx, {
        type: 'pie',
        data: {
            labels: statuses,
            datasets: [{
                data: statusCounts,
                backgroundColor: colors
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });

    // Status Chart
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    charts.statusChart = new Chart(statusCtx, {
        type: 'bar',
        data: {
            labels: statuses,
            datasets: [{
                label: 'Number of Items',
                data: statusCounts,
                backgroundColor: colors
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true } }
        }
    });

    // Timeline Chart
    const timelineCtx = document.getElementById('timelineChart').getContext('2d');
    const days = parseInt(document.getElementById('timeRange').value);
    const labels = Array.from({length: days}, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() + i);
        return window.utils.formatDate(date);
    });

    charts.timelineChart = new Chart(timelineCtx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Items Expiring',
                data: labels.map(date => {
                    const targetDate = new Date(date);
                    return items.filter(item => 
                        new Date(item.expiryDate).toDateString() === targetDate.toDateString()
                    ).length;
                }),
                borderColor: '#4CAF50',
                tension: 0.1,
                fill: true,
                backgroundColor: 'rgba(76, 175, 80, 0.1)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true } }
        }
    });

    // Update summary stats
    document.getElementById('totalItems').textContent = items.length;
    document.getElementById('expiringItems').textContent = statusCounts[1];
    document.getElementById('expiredItems').textContent = statusCounts[2];
}

// Update analytics table
function updateAnalyticsTable(items) {
    const tableBody = document.getElementById('analyticsList');
    tableBody.innerHTML = '';
    
    if (items.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; padding: 2em;">
                    <i class="fas fa-box-open" style="color: #4CAF50; font-size: 2em;"></i>
                    <p style="margin-top: 0.5em;">No items in inventory</p>
                </td>
            </tr>
        `;
        return;
    }
    
    const sortedItems = window.utils.sortItems(items, 'daysLeft', 'asc');
    
    sortedItems.forEach(item => {
        const expiryDate = new Date(item.expiryDate);
        const daysLeft = window.utils.calculateDaysLeft(expiryDate);
        const status = window.utils.getStatus(daysLeft);
        const statusClass = window.utils.getStatusClass(daysLeft);
        
        // Add action icons for expiring items
        let actionIcons = '';
        if (daysLeft <= 3 && daysLeft >= 0) {
            actionIcons = `
                <div class="quick-actions">
                    <a href="#" class="quick-action" onclick="showDiscountPrompt('${item.id}')">
                        <i class="fas fa-tag"></i> Apply Discount
                    </a>
                    <a href="#" class="quick-action" onclick="showBulkSalePrompt('${item.id}')">
                        <i class="fas fa-boxes"></i> Bulk Sale
                    </a>
                    <a href="#" class="quick-action" onclick="showBundleDealPrompt('${item.id}')">
                        <i class="fas fa-layer-group"></i> Bundle Deal
                    </a>
                </div>
            `;
        }

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                ${item.name}
                ${daysLeft <= 3 && daysLeft >= 0 ? '<i class="fas fa-exclamation-triangle alarm-icon"></i>' : ''}
            </td>
            <td>${window.utils.formatDate(expiryDate)}</td>
            <td>${daysLeft} days</td>
            <td>
                <span class="status-badge ${statusClass}">${status}</span>
                ${actionIcons}
            </td>
            <td>
                <button class="delete-btn" onclick="deleteItem('${item.id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Export analytics functions
window.analytics = {
    updateAnalytics,
    destroyCharts
}; 