// Utility functions for the application

// Calculate days left until expiry
function calculateDaysLeft(expiryDate) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(expiryDate);
    expiry.setHours(0, 0, 0, 0);
    const diffTime = expiry - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

// Get status based on days left
function getStatus(daysLeft) {
    if (daysLeft < 0) return 'Expired';
    if (daysLeft === 0) return 'Expires Today';
    if (daysLeft <= 3) return 'Expiring Soon';
    return 'Fresh';
}

// Get CSS class for status
function getStatusClass(daysLeft) {
    if (daysLeft < 0) return 'status-expired';
    if (daysLeft === 0) return 'status-expiring';
    if (daysLeft <= 3) return 'status-expiring';
    return 'status-fresh';
}

// Format date for display
function formatDate(date) {
    const d = new Date(date);
    return d.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Sort items by field
function sortItems(items, field, direction = 'asc') {
    return [...items].sort((a, b) => {
        let comparison = 0;
        
        switch(field) {
            case 'name':
                comparison = a.name.localeCompare(b.name);
                break;
            case 'expiry':
                comparison = new Date(a.expiryDate) - new Date(b.expiryDate);
                break;
            case 'daysLeft':
                comparison = calculateDaysLeft(a.expiryDate) - calculateDaysLeft(b.expiryDate);
                break;
            case 'status':
                comparison = getStatus(calculateDaysLeft(a.expiryDate))
                    .localeCompare(getStatus(calculateDaysLeft(b.expiryDate)));
                break;
        }

        return direction === 'asc' ? comparison : -comparison;
    });
}

// Export utility functions
window.utils = {
    calculateDaysLeft,
    getStatus,
    getStatusClass,
    formatDate,
    showNotification,
    sortItems
}; 