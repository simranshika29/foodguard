const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.')); // Serve static files from current directory

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/foodflow', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB Connected'))
.catch(err => console.error('MongoDB Connection Error:', err));

// Item Schema
const itemSchema = new mongoose.Schema({
    name: { type: String, required: true },
    expiryDate: { type: Date, required: true },
    createdAt: { type: Date, default: Date.now }
});

const Item = mongoose.model('Item', itemSchema);

// Routes
// Get all items
app.get('/api/items', async (req, res) => {
    try {
        const items = await Item.find().sort({ expiryDate: 1 });
        res.json(items);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new item
app.post('/api/items', async (req, res) => {
    try {
        const item = new Item(req.body);
        const newItem = await item.save();
        res.status(201).json(newItem);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete item
app.delete('/api/items/:id', async (req, res) => {
    try {
        await Item.findByIdAndDelete(req.params.id);
        res.json({ message: 'Item deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Search items
app.get('/api/items/search', async (req, res) => {
    try {
        const searchTerm = req.query.q;
        const items = await Item.find({
            name: { $regex: searchTerm, $options: 'i' }
        });
        res.json(items);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get expiring items
app.get('/api/items/expiring', async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const sevenDaysFromNow = new Date(today);
        sevenDaysFromNow.setDate(today.getDate() + 7);

        const items = await Item.find({
            expiryDate: {
                $gte: today,
                $lte: sevenDaysFromNow
            }
        }).sort({ expiryDate: 1 });

        res.json(items);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
}); 