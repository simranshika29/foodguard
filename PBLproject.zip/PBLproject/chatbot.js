class InventoryChatbot {
    constructor() {
        this.apiKey = ''; // OpenAI API key will be set by user
        this.chatHistory = [];
        this.isInitialized = false;
    }

    async initialize(apiKey) {
        if (!apiKey) {
            throw new Error('OpenAI API key is required');
        }
        this.apiKey = apiKey;
        this.isInitialized = true;     
        return true;
    }

    async sendMessage(message) {
        if (!this.isInitialized) {
            throw new Error('Chatbot not initialized. Please set your OpenAI API key first.');
        }

        try {
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [
                        {
                            role: 'system',
                            content: `You are an inventory management assistant. You can:
                            1. Answer questions about inventory status
                            2. Provide suggestions for managing stock
                            3. Help with inventory optimization
                            4. Alert about potential issues
                            Keep responses concise and actionable.`
                        },
                        ...this.chatHistory,
                        { role: 'user', content: message }
                    ],
                    temperature: 0.7,
                    max_tokens: 150
                })
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.error?.message || 'Failed to get response from OpenAI');
            }

            const assistantMessage = data.choices[0].message.content;
            this.chatHistory.push(
                { role: 'user', content: message },
                { role: 'assistant', content: assistantMessage }
            );

            return assistantMessage;
        } catch (error) {
            console.error('Error in chatbot:', error);
            throw error;
        }
    }

    async getInventorySummary() {
        try {
            const items = await window.dbOperations.getAllItems();
            const expiringItems = await window.dbOperations.getExpiringItems();
            
            return {
                totalItems: items.length,
                expiringItems: expiringItems.length,
                items: items
            };
        } catch (error) {
            console.error('Error getting inventory summary:', error);
            throw error;
        }
    }

    clearHistory() {
        this.chatHistory = [];
    }
}

// Create global instance
window.chatbot = new InventoryChatbot();

// Chatbot functionality
let isChatbotOpen = false;

// Toggle chatbot visibility
function toggleChatbot() {
    const chatbot = document.getElementById('chatbot');
    isChatbotOpen = !isChatbotOpen;
    chatbot.style.display = isChatbotOpen ? 'flex' : 'none';
}

// Add message to chat
function addMessage(message, isUser = false) {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
    messageDiv.textContent = message;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Send message to chatbot
async function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    
    if (!message) return;

    // Add user message to chat
    addMessage(message, true);
    chatInput.value = '';

    try {
        // Show loading state
        const loadingMessage = document.createElement('div');
        loadingMessage.className = 'message bot-message';
        loadingMessage.textContent = 'Thinking...';
        document.getElementById('chatMessages').appendChild(loadingMessage);

        // Send message to backend
        const response = await fetch('http://localhost:5000/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message })
        });

        // Remove loading message
        loadingMessage.remove();

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to get response from chatbot');
        }

        const data = await response.json();
        
        // Add bot response to chat
        if (data.response) {
            addMessage(data.response);
        } else {
            addMessage('Sorry, I encountered an error. Please try again.');
        }
    } catch (error) {
        console.error('Chatbot error:', error);
        addMessage('Sorry, I encountered an error. Please try again. Make sure the chatbot server is running on port 5000.');
    }
}

// Initialize chatbot
function initChatbot() {
    // Add welcome message
    addMessage('Hello! I\'m your FoodFlow assistant. How can I help you today?');
    
    // Set up event listeners
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }

    // Test server connection
    fetch('http://localhost:5000/api/health')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'healthy') {
                console.log('Chatbot server is running');
            } else {
                console.error('Chatbot server is not healthy:', data.error);
                addMessage('Warning: Chatbot server is not healthy. Please check the server status.');
            }
        })
        .catch(error => {
            console.error('Chatbot server is not running:', error);
            addMessage('Warning: Chatbot server is not running. Please start the server to use the chatbot.');
        });
}

// Export functions
window.chatbot = {
    initChatbot,
    toggleChatbot,
    sendMessage
};