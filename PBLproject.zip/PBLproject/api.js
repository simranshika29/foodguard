// Use localStorage for user-specific data storage
const STORAGE_PREFIX = 'foodflow_items_';

// Get storage key for current user
function getStorageKey() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        throw new Error('User not authenticated');
    }
    return STORAGE_PREFIX + currentUser.email.toLowerCase();
}

// Get all items for current user
async function getAllItems() {
    try {
        const storageKey = getStorageKey();
        const items = JSON.parse(localStorage.getItem(storageKey) || '[]');
        return items;
    } catch (error) {
        console.error('Error getting items:', error);
        return [];
    }
}

// Add a new item for current user
async function addItem(item) {
    try {
        const storageKey = getStorageKey();
        const items = await getAllItems();
        const newItem = {
            id: Date.now().toString(), // Generate a unique ID
            ...item,
            createdAt: new Date().toISOString()
        };
        items.push(newItem);
        localStorage.setItem(storageKey, JSON.stringify(items));
        return newItem;
    } catch (error) {
        console.error('Error adding item:', error);
        throw error;
    }
}

// Delete an item for current user
async function deleteItem(id) {
    try {
        const storageKey = getStorageKey();
        const items = await getAllItems();
        const filteredItems = items.filter(item => item.id !== id);
        localStorage.setItem(storageKey, JSON.stringify(filteredItems));
        return true;
    } catch (error) {
        console.error('Error deleting item:', error);
        throw error;
    }
}

// Update an item for current user
async function updateItem(id, updatedItem) {
    try {
        const storageKey = getStorageKey();
        const items = await getAllItems();
        const index = items.findIndex(item => item.id === id);
        if (index !== -1) {
            items[index] = { ...items[index], ...updatedItem };
            localStorage.setItem(storageKey, JSON.stringify(items));
            return items[index];
        }
        throw new Error('Item not found');
    } catch (error) {
        console.error('Error updating item:', error);
        throw error;
    }
}

// Search items for current user
async function searchItems(query) {
    try {
        const items = await getAllItems();
        return items.filter(item => 
            item.name.toLowerCase().includes(query.toLowerCase())
        );
    } catch (error) {
        console.error('Error searching items:', error);
        return [];
    }
}

// Get expiring items for current user
async function getExpiringItems() {
    try {
        const items = await getAllItems();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const threeDaysFromNow = new Date(today);
        threeDaysFromNow.setDate(today.getDate() + 3);

        return items.filter(item => {
            const expiryDate = new Date(item.expiryDate);
            return expiryDate >= today && expiryDate <= threeDaysFromNow;
        });
    } catch (error) {
        console.error('Error getting expiring items:', error);
        return [];
    }
}

// Clear all items from storage for current user
function clearAllItems() {
    try {
        const storageKey = getStorageKey();
        localStorage.removeItem(storageKey);
        return true;
    } catch (error) {
        console.error('Error clearing items:', error);
        return false;
    }
}

// Export functions
window.api = {
    getAllItems,
    addItem,
    deleteItem,
    updateItem,
    searchItems,
    getExpiringItems,
    clearAllItems
}; 