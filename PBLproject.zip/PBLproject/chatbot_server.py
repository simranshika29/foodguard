from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import os
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# Configure OpenAI
api_key = os.getenv('OPENAI_API_KEY')
if not api_key:
    logger.error("OpenAI API key not found in environment variables")
    raise ValueError("OpenAI API key not found in environment variables")

openai.api_key = api_key

# System prompt to define the chatbot's role
SYSTEM_PROMPT = """You are an AI assistant for FoodFlow, a food inventory management system. 
Your role is to help users manage their food inventory by:
1. Providing information about food storage and shelf life
2. Suggesting recipes based on available ingredients
3. Helping with inventory management best practices
4. Answering questions about food safety and expiration
5. Providing tips for reducing food waste

Always be friendly, professional, and focused on food management topics."""

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        if not data:
            logger.error("No JSON data received")
            return jsonify({'error': 'No data provided'}), 400

        user_message = data.get('message', '')
        if not user_message:
            logger.error("No message provided in request")
            return jsonify({'error': 'No message provided'}), 400

        logger.info(f"Received message: {user_message}")

        # Create chat completion
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_message}
            ],
            max_tokens=150,
            temperature=0.7,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )

        # Extract the assistant's response
        assistant_response = response.choices[0].message.content
        logger.info(f"Generated response: {assistant_response}")

        return jsonify({
            'response': assistant_response,
            'status': 'success'
        })

    except openai.error.AuthenticationError:
        logger.error("OpenAI API authentication failed")
        return jsonify({
            'error': 'Authentication failed with OpenAI API',
            'details': 'Please check your API key'
        }), 401
    except openai.error.RateLimitError:
        logger.error("OpenAI API rate limit exceeded")
        return jsonify({
            'error': 'Rate limit exceeded',
            'details': 'Please try again later'
        }), 429
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return jsonify({
            'error': 'Failed to process request',
            'details': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    try:
        # Test OpenAI API connection
        openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "test"}],
            max_tokens=5
        )
        return jsonify({'status': 'healthy'})
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return jsonify({'status': 'unhealthy', 'error': str(e)}), 500

if __name__ == '__main__':
    logger.info("Starting chatbot server...")
    app.run(debug=True, port=5000) 