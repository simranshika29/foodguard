// Main application functionality

let items = [];
let currentSort = { field: null, direction: 'asc' };

// Add item function
async function addItem() {
    const nameInput = document.getElementById('itemName');
    const expiryInput = document.getElementById('expiryDate');
    
    const name = nameInput.value.trim();
    const expiryDate = expiryInput.value;
    
    if (!name || !expiryDate) {
        window.utils.showNotification('Please fill in all fields', 'error');
        return;
    }
    
    try {
        await window.api.addItem({ name, expiryDate });
        nameInput.value = '';
        expiryInput.value = '';
        window.utils.showNotification('Item added successfully', 'success');
        loadExpiringItems();
    } catch (error) {
        console.error('Error adding item:', error);
        window.utils.showNotification('Failed to add item', 'error');
    }
}

// Delete item function
async function deleteItem(id) {
    if (!confirm('Are you sure you want to delete this item?')) {
        return;
    }
    
    try {
        await window.api.deleteItem(id);
        window.utils.showNotification('Item deleted successfully', 'success');
        loadExpiringItems();
    } catch (error) {
        console.error('Error deleting item:', error);
        window.utils.showNotification('Failed to delete item', 'error');
    }
}

// Filter items function
async function filterItems() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    try {
        const items = await window.api.searchItems(searchTerm);
        updateTable(items);
    } catch (error) {
        console.error('Error filtering items:', error);
        window.utils.showNotification('Failed to filter items', 'error');
    }
}

// Load items function
async function loadItems() {
    try {
        const items = await window.api.getAllItems();
        updateTable(items);
    } catch (error) {
        console.error('Error loading items:', error);
        window.utils.showNotification('Failed to load items', 'error');
    }
}

// Load expiring items function
async function loadExpiringItems() {
    try {
        const items = await window.api.getExpiringItems();
        updateTable(items);
    } catch (error) {
        console.error('Error loading expiring items:', error);
        window.utils.showNotification('Failed to load expiring items', 'error');
    }
}

// Update table function
function updateTable(items) {
    const tbody = document.getElementById('itemList');
    tbody.innerHTML = '';
    
    if (items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="no-items">No items found</td></tr>';
        return;
    }
    
    items.forEach(item => {
        const daysLeft = window.utils.calculateDaysLeft(new Date(item.expiryDate));
        const status = window.utils.getStatus(daysLeft);
        const statusClass = window.utils.getStatusClass(daysLeft);
        
        // Add action icons for expiring items
        let actionIcons = '';
        if (daysLeft <= 3 && daysLeft >= 0) {
            actionIcons = `
                <div class="quick-actions">
                    <a href="#" class="quick-action" onclick="showDiscountPrompt('${item.id}')">
                        <i class="fas fa-tag"></i> Apply Discount
                    </a>
                    <a href="#" class="quick-action" onclick="showBulkSalePrompt('${item.id}')">
                        <i class="fas fa-boxes"></i> Bulk Sale
                    </a>
                    <a href="#" class="quick-action" onclick="showBundleDealPrompt('${item.id}')">
                        <i class="fas fa-layer-group"></i> Bundle Deal
                    </a>
                </div>
            `;
        }
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                ${item.name}
                ${daysLeft <= 3 && daysLeft >= 0 ? '<i class="fas fa-exclamation-triangle alarm-icon"></i>' : ''}
            </td>
            <td>${window.utils.formatDate(new Date(item.expiryDate))}</td>
            <td>${daysLeft} days</td>
            <td>
                <span class="status-badge ${statusClass}">${status}</span>
                ${actionIcons}
            </td>
            <td>
                <button onclick="deleteItem('${item.id}')" class="delete-btn">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Check expiring items function
async function checkExpiringItems() {
    try {
        const items = await window.api.getExpiringItems();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        items.forEach(item => {
            const expiryDate = new Date(item.expiryDate);
            const daysLeft = window.utils.calculateDaysLeft(expiryDate);
            
            if (daysLeft === 0) {
                window.utils.showNotification(`${item.name} expires today!`, 'warning');
            } else if (daysLeft === 1) {
                window.utils.showNotification(`${item.name} expires tomorrow!`, 'warning');
            } else if (daysLeft <= 3) {
                window.utils.showNotification(`${item.name} expires in ${daysLeft} days!`, 'warning');
            }
        });
    } catch (error) {
        console.error('Error checking expiring items:', error);
    }
}

// Navigation functions
function showHome() {
    document.getElementById('homeSection').style.display = 'block';
    document.getElementById('analyticsSection').style.display = 'none';
    document.getElementById('settingsSection').style.display = 'none';
    loadItems();
}

function showAnalytics() {
    document.getElementById('homeSection').style.display = 'none';
    document.getElementById('analyticsSection').style.display = 'block';
    document.getElementById('settingsSection').style.display = 'none';
    window.analytics.updateAnalytics();
}

function showSettings() {
    document.getElementById('homeSection').style.display = 'none';
    document.getElementById('analyticsSection').style.display = 'none';
    document.getElementById('settingsSection').style.display = 'block';
}

// Quick action functions
function showDiscountPrompt() {
    window.utils.showNotification('Discount feature coming soon!', 'info');
}

function showBulkSalePrompt() {
    window.utils.showNotification('Bulk sale feature coming soon!', 'info');
}

function showBundleDealPrompt() {
    window.utils.showNotification('Bundle deal feature coming soon!', 'info');
}

function showScannerMessage() {
    window.utils.showNotification('Scanner feature coming soon!', 'info');
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    // Initialize authentication
    window.auth.initAuth();
    
    // Initialize analytics
    window.analytics.initAnalytics();
    
    // Initialize chatbot
    window.chatbot.initChatbot();
    
    // Initialize branding
    window.branding.initBranding();
    
    // Show home section by default
    showHome();
    
    loadItems();
    checkExpiringItems();
    // Check for expiring items every hour
    setInterval(checkExpiringItems, 3600000);
}); 