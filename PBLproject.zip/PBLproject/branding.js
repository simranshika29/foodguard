// Branding modal functionality

// Show branding modal
function showBrandingModal() {
    const modal = document.getElementById('brandingModal');
    if (!modal) {
        console.error('Branding modal not found!');
        return;
    }

    // Add active class with a slight delay for animation
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);

    // Add click outside listener
    modal.addEventListener('click', handleOutsideClick);
}

// Close branding modal
function closeBrandingModal() {
    const modal = document.getElementById('brandingModal');
    if (!modal) return;

    // Remove active class
    modal.classList.remove('active');

    // Remove click outside listener
    modal.removeEventListener('click', handleOutsideClick);
}

// Handle clicks outside the modal
function handleOutsideClick(event) {
    const modal = document.getElementById('brandingModal');
    const modalContent = modal.querySelector('.modal-content');
    
    // Check if click was outside the modal content
    if (event.target === modal) {
        closeBrandingModal();
    }
}

// Initialize branding functionality
function initBranding() {
    // Add keyboard event listener for ESC key
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeBrandingModal();
        }
    });
}

// Export functions
window.branding = {
    showBrandingModal,
    closeBrandingModal,
    initBranding
}; 